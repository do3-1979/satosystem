import smtplib
from email.message import EmailMessage
from datetime import datetime

with open( "bot_02.log" ) as file:   # さっきのログファイルを指定して読み込み
	msg = EmailMessage()
	msg.set_content(file.read())

msg["Subject"] = "BOT稼働状況の通知：{}".format(datetime.now().strftime("%Y-%m-%d-%H-%M"))
msg["From"] = "big_my_secret@yahoo.co.jp"         # 送信元のアドレス
msg["To"] = "big_my_secret@yahoo.co.jp"           # 受け取りたいアドレス

server = smtplib.SMTP("smtp.mail.yahoo.co.jp",465)    # これはYahoo mailのSMTPなら共通
server.starttls()
server.login("big_my_secret", "1789bmsyy")            # yahooのアカウント名とパスワード
server.sendmail( msg["From"],msg["To"],msg.as_string() )
server.close()