import requests
from datetime import datetime
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from pprint import pprint
import ccxt
import config

#--------設定項目--------

bitmex = ccxt.bitmex()        # 取引所の定義
bitmex.apiKey = config.apiKey # APIキーを設定
bitmex.secret = config.secret # APIシークレットを設定
bitmex.urls['api'] = bitmex.urls['test'] #テスト用 本番口座の場合は不要

chart_sec = 60             #  １時間足を使用
buy_term =  30             #  買いエントリーのブレイク期間の設定
sell_term = 30             #  売りエントリーのブレイク期間の設定

judge_price={
  "BUY" : "high_price",    #  ブレイク判断　高値（high_price)か終値（close_price）を使用
  "SELL": "low_price"      #  ブレイク判断　安値 (low_price)か終値（close_price）を使用
}

volatility_term = 30       # 平均ボラティリティの計算に使う期間
stop_range = 1             # 何レンジ幅にストップを入れるか
trade_risk = 0.07          # 1トレードあたり口座の何％まで損失を許容するか
levarage = 10              # レバレッジ倍率の設定
start_funds = 10000        # シミュレーション時の初期資金

entry_times = 10           # 何回に分けて追加ポジションを取るか
entry_range = 2            # 何レンジごとに追加ポジションを取るか

stop_AF = 0.02             # 加速係数
stop_AF_add = 0.02         # 加速係数を増やす度合
stop_AF_max = 0.2          # 加速係数の上限

wait = 5                  # ループの待機時間
order_retry_times = 2      # オーダー時の待機時間倍率
slippage = 0.001           # 手数料・スリッページ

# CryptowatchのAPIを使用する関数
def get_price(min, before=0, after=0):
	price = []
	params = {"periods" : min }
	if before != 0:
		params["before"] = before
	if after != 0:
		params["after"] = after

	while True:
		try:
			response = requests.get("https://api.cryptowat.ch/markets/bitmex/btcusd-perpetual-futures/ohlc", params, timeout = 5)
			response.raise_for_status()
			data = response.json()
			break
		except requests.exceptions.RequestException as e:
			log = "Cryptowatchの価格取得でエラー発生 : " + str(e)
			out_log(log, flag)
			out_log("{0}秒待機してやり直します".format(wait), flag)
			time.sleep(wait)

	if data["result"][str(min)] is not None:
		for i in data["result"][str(min)]:
			if i[1] != 0 and i[2] != 0 and i[3] != 0 and i[4] != 0:
				price.append({ "close_time" : i[0],
					"close_time_dt" : datetime.fromtimestamp(i[0]).strftime('%Y/%m/%d %H:%M'),
					"open_price" : i[1],
					"high_price" : i[2],
					"low_price" : i[3],
					"close_price": i[4] })
		return price
		
	else:
		out_log("データが存在しません", flag)
		return None


# 時間と高値・安値をログに記録する関数
def log_price( data, flag ):
	log =  "時間： " + str(datetime.fromtimestamp(data["close_time"]).strftime('%Y/%m/%d %H:%M')) + " 高値： " + str(data["high_price"]) + " 安値： " + str(data["low_price"]) + " 終値： " + str(data["close_price"]) + "\n"
	out_log(log, flag)
	return flag

#-------------補助ツールの関数--------------

def out_log(log_msg, flag):
	# print出力
	
	print(log_msg.strip("\n"))
	
	# ファイル出力
	#flag["records"]["log"].append(log_msg)

def create_order( symbol, type, side, amount, price=None ):

    """
    引数
    symbol(str) : 'BTC/USD'
    type(str) : 'Limit' -> 指値　/ 'Market' -> 成行
    side(str) : 'Buy' -> 買い / 'Sell' -> 売り
    amount(float/int) -> 注文枚数
    price(float/int) -> 注文価格(成行の場合は省略可)
    """

    while True:
        result = {}

        try:
            # Stop注文の場合はstopPxに指値を入れる（指値を下回ると成り行き決済)
            if type == 'Stop':
                create_order = bitmex.privatePostOrder({
                    'symbol' : symbol,
                    'type' : type,
                    'side' : side,
                    'orderQty' : amount,
                    'stopPx' : price,
                    })
                pprint(create_order)
            else:
                create_order = bitmex.privatePostOrder({
                    'symbol' : symbol,
                    'type' : type,
                    'side' : side,
                    'orderQty' : amount,
                    'price' : price
                    })
                pprint(create_order)
            break
        except ccxt.BaseError as e:
            out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
            out_log("注文の通信が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
            time.sleep(wait*order_retry_times)

    return create_order

# 売買注文の約定確認を行う関数
def check_order():
    """
    引数 : なし
    戻り値 : 未約定の注文ID
    """
    while True:
        try:
            out_log("約定を確認します\n", flag)

            orders = []
            order_id = []
            len_orders = 0
            orders = bitmex.fetch_open_orders()

            if len(orders) > 0:
                len_orders = len(orders)
                out_log("ID = {0} が残っています\n".format(len_orders), flag)

                for i in orders:
                    order_id.append(i['info']['orderID'])

                print(order_id)

            elif orders == []:
                out_log("残っている注文はありません\n", flag)
                order_id = 0

            return order_id

        except ccxt.BaseError as e:
            out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
            out_log("売買注文の約定確認が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
            time.sleep(wait*order_retry_times)

# 売買注文のキャンセルを行う関数
def cancel_order(order_id):
    """
    引数 : なし
    戻り値 : キャンセルの結果（全部成功=1、それ以外=0）
    """
    while True:
        try:
            out_log("オーダーキャンセル実施\n", flag)

            cancel_order = []

            if order_id != 0:
                for i in order_id:
                    cancel_result = bitmex.cancel_order(i)
                    cancel_order.append(cancel_result['info']['ordStatus'])


            return cancel_order

        except ccxt.BaseError as e:
            out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
            out_log("売買注文キャンセルが失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
            time.sleep(wait*order_retry_times)

# 口座残高を取得する関数
def get_collateral():
    """
    引数 : なし
    戻り値 
        result['total'] # 証拠金総額
        result['used'] # 拘束中証拠金
        result['free'] # 使用可能証拠金
    """
    while True:
        result = {}
        try:
            # 口座残高を取得
            collateral = bitmex.fetch_balance()
            # 総額
            result['total'] = collateral['BTC']['total']
            # 拘束中
            result['used'] = collateral['BTC']['used']
            # 使用可能
            result['free'] = collateral['BTC']['free']

            return result

        except ccxt.BaseError as e:
            out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
            out_log("口座残高取得が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
            time.sleep(wait*order_retry_times)

# ポジション情報を取得する関数
def get_position():
    """
    引数 : なし
    戻り値 
        result['side'] # None->ノーポジ、BUY->ロング、SELL->ショート
        result['used'] # 拘束中証拠金
        result['free'] # 使用可能証拠金
        result['lots'] # ロットサイズ
        result['averageprice'] # 全ロットの平均価格
    """
    while True:
        result = {}
        try:

            position = bitmex.private_get_position()
            if position == []:
                result['side'] = 'NONE'
                result['lots'] = 0
            else:
                result['lots'] = abs(float(position[0]['currentQty']))

                if position[0]['currentQty'] < 0:
                    result['side'] = 'SELL'
                elif position[0]['currentQty'] > 0:
                    result['side'] = 'BUY'
                else:
                    result['side'] = 'NONE'

            return result

        except ccxt.BaseError as e:
            out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
            out_log("ポジション情報取得が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
            time.sleep(wait*order_retry_times)

            return result

flag = {
	"position":{
		"exist" : False,
		"side" : "",
		"price": 0,
		"stop":0,
		"stop-AF": stop_AF,
		"stop-EP":0,
		"ATR":0,
		"lot":0,
		"count":0
	},
	"order":{
		"exist" : False,
		"side" : "",
		"count" : 0
	},
	"add-position":{
		"count":0,
		"first-entry-price":0,
		"last-entry-price":0,
		"unit-range":0,
		"unit-size":0,
		"stop":0
	},
	"records":{
		"date":[],
		"profit":[],
		"return":[],
		"side":[],
		"stop-count":[],
		"funds" : start_funds,
		"holding-periods":[],
		"slippage":[],
		"log":[]
	}
}

while True:
	# 価格を取得
    data = get_price(chart_sec)
    new_price = data[-2]
    
    log_price(new_price, flag)
    
    """
    # 口座残高を取得
    引数 : なし
    戻り値 
        result['total'] # 証拠金総額
        result['used'] # 拘束中証拠金
        result['free'] # 使用可能証拠金
    """
    result = get_collateral()
    out_log( "証拠金総額     = {0}\n".format(str(result['total'])), flag)
    out_log( "拘束中証拠金   = {0}\n".format(str(result['used'])), flag)
    out_log( "使用可能証拠金 = {0}\n".format(str(result['free'])), flag)
    """
    create_order(
		symbol = 'XBTUSD',
		type='Limit',
		side='Buy',
		price=new_price["close_price"]-500,
		amount=100)
    flag["order"]["exist"] = True
    """
    # ポジション残高を取得
    """
    引数 : なし
    戻り値 
        result['side'] # None->ノーポジ、BUY->ロング、SELL->ショート
        result['lots'] # ロットサイズ
    """
    result = get_position()
    # out_log( "ポジション         = {0}\n".format(str(result['side'])), flag)
    out_log( "ロットサイズ       = {0}\n".format(str(result['lots'])), flag)
    out_log( "ポジション         = {0}\n".format(result['side']), flag)
    
    # オーダーチェック
    check_order()

    time.sleep(wait)

