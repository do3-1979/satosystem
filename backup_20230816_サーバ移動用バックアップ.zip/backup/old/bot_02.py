import requests
from datetime import datetime
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from pprint import pprint
import ccxt
import config

import time
from logging import getLogger,Formatter,StreamHandler,FileHandler,INFO

logger = getLogger(__name__)
handlerSh = StreamHandler()
handlerFile = FileHandler("./bot_02.log") # ログファイルの出力先とファイル名を指定
handlerSh.setLevel(INFO)
handlerFile.setLevel(INFO)
logger.setLevel(INFO)
logger.addHandler(handlerSh)
logger.addHandler(handlerFile)


#--------設定項目--------

bitmex = ccxt.bitmex()		  # 取引所の定義
bitmex.apiKey = config.apiKey # APIキーを設定
bitmex.secret = config.secret # APIシークレットを設定
bitmex.urls['api'] = bitmex.urls['test'] #テスト用 本番口座の場合は不要

symbol_type = "XBTUSD"	   # 扱う通貨ペア
log_unit = "USD"		   # 通貨単位
lot_limit_lower = 0.001	   # 注文できる最小lot数
balance_limit = 10		   # 注文できる最小証拠金[USD]

chart_sec = 7200		   # 1時間足を使用
#chart_sec = 300            # 5分足を使用
#chart_sec = 60				# 1分足を使用
buy_term =	39			   # 買いエントリーのブレイク期間の設定
sell_term = 39			   # 売りエントリーのブレイク期間の設定

judge_price={
  "BUY" : "close_price",	   # ブレイク判断　高値（high_price)か終値（close_price）を使用
  "SELL": "close_price"	   # ブレイク判断　安値 (low_price)か終値（close_price）を使用
}

volatility_term = 22	   # 平均ボラティリティの計算に使う期間
stop_range = 1			   # 何レンジ幅にストップを入れるか
trade_risk = 0.03     	   # 1トレードあたり口座の何％まで損失を許容するか
levarage = 100			   # レバレッジ倍率の設定
#start_funds = 10000	   # シミュレーション時の初期資金[円]
start_funds = 0.03 * 8178.5		   # シミュレーション時の初期資金[XBT]

entry_times = 20		   # 何回に分けて追加ポジションを取るか
entry_range = 2			   # 何レンジごとに追加ポジションを取るか

stop_AF = 0.02			   # 加速係数
stop_AF_add = 0.02		   # 加速係数を増やす度合
stop_AF_max = 0.2		   # 加速係数の上限

wait = 10				   # ループの待機時間
order_retry_times = 3	   # オーダー時の待機時間倍率
slippage = 0.001		   # 手数料・スリッページ

is_back_test = True	   # back test フラグ

#-------------補助ツールの関数--------------

def out_log(log_msg, flag):

	# print出力 ※logger .infoなら要らない
	# print(log_msg.strip("\n"))
	
	# ログ出力
	logger.info(log_msg.strip("\n"))
	
	# ファイル出力
	flag["records"]["log"].append(log_msg)

# LINEに通知する関数
def line_notify( text ):
	url = "https://notify-api.line.me/api/notify"
	data = {"message" : text}
	headers = {"Authorization": "Bearer " + config.line_token} 
	requests.post(url, data=data, headers=headers)

def out_log_with_line(log_msg, flag):

	# print出力 ※logger .infoなら要らない
	# print(log_msg.strip("\n"))
	
	# ログ出力
	logger.info(log_msg.strip("\n"))
	
	# LINE通知
	if is_back_test is False:
		line_notify("\n" + log_msg)
	
	# ファイル出力
	flag["records"]["log"].append(log_msg)

# CryptowatchのAPIを使用する関数
def get_price(min, before=0, after=0):
	price = []
	params = {"periods" : min }
	if before != 0:
		params["before"] = before
	if after != 0:
		params["after"] = after

	while True:
		try:
			response = requests.get("https://api.cryptowat.ch/markets/bitmex/btcusd-perpetual-futures/ohlc", params, timeout = 5)
			response.raise_for_status()
			data = response.json()
			break
		except requests.exceptions.RequestException as e:
			log = "Cryptowatchの価格取得でエラー発生 : " + str(e)
			out_log(log, flag)
			out_log("{0}秒待機してやり直します".format(wait), flag)
			time.sleep(wait)

	if data["result"][str(min)] is not None:
		for i in data["result"][str(min)]:
			if i[1] != 0 and i[2] != 0 and i[3] != 0 and i[4] != 0:
				price.append({ "close_time" : i[0],
					"close_time_dt" : datetime.fromtimestamp(i[0]).strftime('%Y/%m/%d %H:%M'),
					"open_price" : i[1],
					"high_price" : i[2],
					"low_price" : i[3],
					"close_price": i[4] })
		return price
		
	else:
		out_log("データが存在しません", flag)
		return None


# 時間と高値・安値をログに記録する関数
def log_price( data, flag ):
	log =  "時間： " + str(datetime.fromtimestamp(data["close_time"]).strftime('%Y/%m/%d %H:%M')) + " 高値： " + str(data["high_price"]) + " 安値： " + str(data["low_price"]) + " 終値： " + str(data["close_price"]) + "\n"
	out_log(log, flag)
	return flag

# 平均ボラティリティを計算する関数
def calculate_volatility( last_data ):
	high_sum = sum(i["high_price"] for i in last_data[-1 * volatility_term :])
	low_sum	 = sum(i["low_price"]  for i in last_data[-1 * volatility_term :])
	volatility = round((high_sum - low_sum) / volatility_term)
	out_log("現在の{0}期間の平均ボラティリティは{1}{2}です\n".format( volatility_term, volatility, log_unit ), flag)
	return volatility

# XBTからUSDに変換する関数
def XBTtuXBTUSD( data, xbtval, flag ):
	xbtusdval = round( data["close_price"] * xbtval, 6 )
	out_log("現在レート {}[XBTUSD] {} [XBT] → {} [XBTUSD]\n".format( data["close_price"], round(xbtval,6), xbtusdval ), flag)
	return xbtusdval, flag

# ロットを発注量に変換する関数
def lot_to_amount( data, lot, flag ):
	amount = round( data["close_price"] * lot )
	out_log("現在レート {}[XBTUSD] {} [lot] → {} [USD]\n".format( data["close_price"], round(lot,6), amount ), flag)
	return amount, flag

#-------------資金管理の関数--------------

# 注文ロットを計算する関数
# ロットとは、現在価格に掛け算して分割する値。オリジナルでは0.01以上を想定
# 0.01で7325だったら、0.01がロット、73が購入価格（数量）である
# オーダー時は、数量(amount)を入れなければならない
# 数量は、lot x close_price で計算する案でやってみる
def calculate_lot( last_data,data,flag ):

	# 口座残高を取得する
	if is_back_test is True:
		balance = flag["records"]["funds"]
	else:
		result = get_collateral()
		# 証拠金をXBTからUSDに変換する
		balance, flag = XBTtuXBTUSD(data, result['total'], flag)
		
	# 口座残高が最低額を下回ったら、lot=0で抜ける
	if balance < balance_limit:

		volatility = calculate_volatility( last_data )
		stop = stop_range * volatility
		
		out_log("証拠金{0}がが最低額{1}を下回ったので発注できません\n".format( round(balance,4), balance_limit ), flag)

		lot = 0

		return lot,stop,flag

	# 最初のエントリーの場合
	if flag["add-position"]["count"] == 0:
		
		# １回の注文単位（ロット数）と、追加ポジの基準レンジを計算する
		volatility = calculate_volatility( last_data )
		stop = stop_range * volatility
		calc_lot = np.floor( balance * trade_risk * 100 / stop ) / 100

		flag["add-position"]["unit-size"] = np.floor( calc_lot * 100 / entry_times ) / 100
		flag["add-position"]["unit-range"] = round( volatility * entry_range )
		flag["add-position"]["stop"] = stop
		flag["position"]["ATR"] = round( volatility )
		
		out_log("\n現在のアカウント残高は{0}USDです\n".format( round(balance,2) ), flag)
		out_log("許容リスクから購入できる枚数は最大{0}{1}までです\n".format( round(calc_lot,4), log_unit ), flag)
		out_log("{0}回に分けて{1}{2}ずつ注文します\n".format( entry_times, round(flag["add-position"]["unit-size"],4), log_unit ), flag)

	# ２回目以降のエントリーの場合
	else:
		# 現在の証拠金から購入済枚数費用を引いた額
		# 証拠金 - 枚数に必要な証拠金数 / レバレッジ
		balance = round( balance - flag["position"]["price"] * flag["position"]["lot"] / levarage )
		out_log("lot = {}\n".format(flag["position"]["lot"]),flag)
		out_log("position_price = {}\n".format(flag["position"]["price"]),flag)
		out_log("balance {} - used {}\n".format(balance, round(flag["position"]["lot"] / levarage,4)), flag)
		#balance = balance - flag["position"]["lot"] / levarage / flag["position"]["price"] # 残高 - 購入額 x ロット数

	# ストップ幅には、最初のエントリー時に計算したボラティリティを使う
	stop = flag["add-position"]["stop"]
	
	# 実際に購入可能な枚数を計算する
	able_lot = np.floor( balance * levarage * 100 / data["close_price"]  ) / 100
	lot = min(able_lot, flag["add-position"]["unit-size"])

	out_log("証拠金から購入できる枚数は最大{0}{1}までです\n".format( round(lot,4), log_unit ), flag)
	return lot,stop,flag



# 複数回に分けて追加ポジションを取る関数
def add_position( data,flag ):
	
	out_log("#-------------add_position start----------------\n", flag)
	# ポジションがない場合は何もしない
	if flag["position"]["exist"] == False:
		out_log("#-------------add_position end----------------\n", flag)	  
		return flag
	
	# 最初（１回目）のエントリー価格を記録
	if flag["add-position"]["count"] == 0:
		flag["add-position"]["first-entry-price"] = flag["position"]["price"]
		flag["add-position"]["last-entry-price"] = flag["position"]["price"]
		flag["add-position"]["count"] += 1
	
	while True:
		
		# 以下の場合は、追加ポジションを取らない
		if flag["add-position"]["count"] >= entry_times:
			out_log("#-------------add_position end----------------\n", flag) 
			return flag
		
		# この関数の中で使う変数を用意
		first_entry_price = flag["add-position"]["first-entry-price"]
		last_entry_price = flag["add-position"]["last-entry-price"]
		unit_range = flag["add-position"]["unit-range"]
		current_price = data["close_price"]
		
		
		# 価格がエントリー方向に基準レンジ分だけ進んだか判定する
		should_add_position = False
		if flag["position"]["side"] == "BUY" and (current_price - last_entry_price) > unit_range:
			should_add_position = True
		elif flag["position"]["side"] == "SELL" and (last_entry_price - current_price) > unit_range:
			should_add_position = True
		else:
			break
		
		# 基準レンジ分進んでいれば追加注文を出す
		if should_add_position == True:
			out_log("\n前回のエントリー価格{0}USDからブレイクアウトの方向に{1}ATR（{2}USD）以上動きました\n".format( last_entry_price, entry_range, round( unit_range ) ), flag)
			out_log_with_line("{0}/{1}回目の追加注文を出します\n".format(flag["add-position"]["count"] + 1, entry_times), flag)
			
			# 注文サイズを計算
			lot,stop,flag = calculate_lot( last_data,data,flag )
			if lot < lot_limit_lower:
				out_log_with_line("注文可能枚数{}が、最低注文単位に満たなかったので注文を見送ります\n".format(lot), flag)
				flag["add-position"]["count"] += 1
				out_log("#-------------add_position end----------------\n", flag) 
				return flag
			
			# 追加注文を出す
			if flag["position"]["side"] == "BUY":
				entry_price = first_entry_price + (flag["add-position"]["count"] * unit_range)
				if is_back_test is True:
					entry_price = round((1 + slippage) * entry_price)
				
				out_log("現在のポジションに追加して、{0}USDで{1}lotの買い注文を出します\n".format(entry_price,lot), flag)
				order_lot, flag = lot_to_amount(data, lot, flag)
				
				# ここに買い注文のコードを入れる
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Buy',
					amount=order_lot)
				flag["order"]["exist"] = True
				flag["order"]["side"] = "BUY"

			if flag["position"]["side"] == "SELL":
				entry_price = first_entry_price - (flag["add-position"]["count"] * unit_range)
				if is_back_test is True:
					entry_price = round((1 - slippage) * entry_price)
				
				out_log("現在のポジションに追加して、{0}USDで{1}lotの売り注文を出します\n".format(entry_price,lot), flag)
				order_lot, flag = lot_to_amount(data, lot, flag)

				# ここに売り注文のコードを入れる
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Sell',
					amount=order_lot)
				flag["order"]["exist"] = True
				flag["order"]["side"] = "SELL"

			# ポジション全体の情報を更新する
			flag["position"]["stop"] = stop
			flag["position"]["price"] = int(round(( flag["position"]["price"] * flag["position"]["lot"] + entry_price * lot ) / ( flag["position"]["lot"] + lot )))
			flag["position"]["lot"] = np.round( (flag["position"]["lot"] + lot) * 100 ) / 100
			
			if flag["position"]["side"] == "BUY":
				out_log("{0}USDの位置にストップを更新します\n".format(flag["position"]["price"] - stop), flag)
			elif flag["position"]["side"] == "SELL":
				out_log("{0}USDの位置にストップを更新します\n".format(flag["position"]["price"] + stop), flag)
			out_log("現在のポジションの取得単価は{}USDです\n".format(flag["position"]["price"]), flag)
			out_log("現在のポジションサイズは{}lotです\n\n".format(flag["position"]["lot"]), flag)
			
			flag["add-position"]["count"] += 1
			flag["add-position"]["last-entry-price"] = entry_price

	out_log("#-------------add_position end----------------\n", flag) 
	return flag


# トレイリングストップの関数
def trail_stop( data,flag ):

	out_log("#-------------trail_stop start----------------\n", flag)
	# まだ追加ポジションの取得中であれば何もしない
	if flag["add-position"]["count"] < entry_times:
		out_log("#-------------trail_stop end----------------\n", flag)	  
		return flag
	
	# 高値／安値がエントリー価格からいくら離れたか計算
	if flag["position"]["side"] == "BUY":
		moved_range = round( data["high_price"] - flag["position"]["price"] )
	if flag["position"]["side"] == "SELL":
		moved_range = round( flag["position"]["price"] - data["low_price"] )
	
	# 最高値・最安値を更新したか調べる
	if moved_range < 0 or flag["position"]["stop-EP"] >= moved_range:
		out_log("#-------------trail_stop end----------------\n", flag)	  
		return flag
	else:
		flag["position"]["stop-EP"] = moved_range
	
	# 加速係数に応じて損切りラインを動かす
	flag["position"]["stop"] = round(flag["position"]["stop"] - ( moved_range + flag["position"]["stop"] ) * flag["position"]["stop-AF"])
	
	
	# 加速係数を更新
	flag["position"]["stop-AF"] = round( flag["position"]["stop-AF"] + stop_AF_add ,2 )
	if flag["position"]["stop-AF"] >= stop_AF_max:
		flag["position"]["stop-AF"] = stop_AF_max
	
	# ログ出力
	if flag["position"]["side"] == "BUY":
		out_log_with_line("トレイリングストップの発動：ストップ位置を{}USDに動かして、加速係数を{}に更新します\n".format( round(flag["position"]["price"] - flag["position"]["stop"]) , flag["position"]["stop-AF"] ), flag)
	else:
		out_log_with_line("トレイリングストップの発動：ストップ位置を{}USDに動かして、加速係数を{}に更新します\n".format( round(flag["position"]["price"] + flag["position"]["stop"]) , flag["position"]["stop-AF"] ), flag)
	
	out_log("#-------------trail_stop end----------------\n", flag)	  
	return flag
	


#-------------売買ロジックの部分の関数--------------

# ドンチャンブレイクを判定する関数
def donchian( data,last_data ):
	
	highest = max(i["high_price"] for i in last_data[ (-1* buy_term): ])
	if data[ judge_price["BUY"] ] > highest:
		return {"side":"BUY","price":highest}
	
	lowest = min(i["low_price"] for i in last_data[ (-1* sell_term): ])
	if data[ judge_price["SELL"] ] < lowest:
		return {"side":"SELL","price":lowest}
	
	return {"side" : None , "price":0}


# エントリー注文を出す関数
def entry_signal( data,last_data,flag ):
	out_log("#-------------entry_signal start----------------\n", flag)	  
	signal = donchian( data,last_data )
	
	if signal["side"] == "BUY":
		out_log("過去{0}足の最高値{1}USDを、直近の価格が{2}USDでブレイクしました\n".format(buy_term,signal["price"],data[judge_price["BUY"]]), flag)
        
		lot,stop,flag = calculate_lot( last_data,data,flag )
		if lot >= lot_limit_lower:
			out_log_with_line("{0}USDで{1}lotの買い注文を出します\n".format(data["close_price"],lot), flag)
			order_lot, flag = lot_to_amount(data, lot, flag)
			
            # ここに買い注文のコードを入れる
			create_order(
				symbol = symbol_type,
				type='Market',
				side='Buy',
				amount=order_lot)
			flag["order"]["exist"] = True
			flag["order"]["side"] = "BUY"

			out_log_with_line("{0}USDにストップを入れます\n".format(data["close_price"] - stop), flag)
			flag["position"]["lot"],flag["position"]["stop"] = lot,stop
			flag["position"]["exist"] = True
			flag["position"]["side"] = "BUY"
			flag["position"]["price"] = data["close_price"]
		else:
			out_log_with_line("注文可能枚数{0}が、最低注文単位に満たなかったので注文を見送ります\n".format(lot), flag)

	if signal["side"] == "SELL":
		out_log("過去{0}足の最安値{1}USDを、直近の価格が{2}USDでブレイクしました\n".format(sell_term,signal["price"],data[judge_price["SELL"]]), flag)
		
		lot,stop,flag = calculate_lot( last_data,data,flag )
		if lot >= lot_limit_lower:
			out_log_with_line("{0}USDで{1}lotの売り注文を出します\n".format(data["close_price"],lot), flag)
			order_lot, flag = lot_to_amount(data, lot, flag)

			# ここに売り注文のコードを入れる
			create_order(
				symbol = symbol_type,
				type='Market',
				side='Sell',
				amount=order_lot)
			flag["order"]["exist"] = True
			flag["order"]["side"] = "SELL"

			out_log_with_line("{0}USDにストップを入れます\n".format(data["close_price"] + stop), flag)
			flag["position"]["lot"],flag["position"]["stop"] = lot,stop
			flag["position"]["exist"] = True
			flag["position"]["side"] = "SELL"
			flag["position"]["price"] = data["close_price"]
		else:
			out_log_with_line("注文可能枚数{0}が、最低注文単位に満たなかったので注文を見送ります\n".format(lot), flag)
	out_log("#-------------entry_signal end----------------\n", flag) 
	return flag



# 手仕舞いのシグナルが出たら決済の成行注文 + ドテン注文 を出す関数
def close_position( data,last_data,flag ):
	out_log("#-------------close_position start----------------\n", flag)
	if flag["position"]["exist"] == False:
		out_log("#-------------close_position end----------------\n", flag)	  
		return flag
	
	flag["position"]["count"] += 1
	signal = donchian( data,last_data )
	
	if flag["position"]["side"] == "BUY":
		if signal["side"] == "SELL":
			out_log("過去{0}足の最安値{1}USDを、直近の価格が{2}USDでブレイクしました\n".format(sell_term,signal["price"],data[judge_price["SELL"]]), flag)
			out_log_with_line(str(data["close_price"]) + "USDあたりで成行注文を出してポジションを決済します\n", flag)

			# 決済の成行注文コードを入れる
			if is_back_test is True:
				result = {}
				result["side"] = flag["position"]["side"]
				result["lots"] = flag["position"]["lot"] * data["close_price"]
			else:
				result = get_position()

			if (result["side"] == "BUY") and (result["lots"] > 0):
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Sell',
					amount=result["lots"])
				flag["order"]["exist"] = True
				flag["order"]["side"] = "SELL"

			records( flag,data,data["close_price"] )
			flag["position"]["exist"] = False
			flag["position"]["count"] = 0
			flag["position"]["stop-AF"] = stop_AF
			flag["position"]["stop-EP"] = 0
			flag["add-position"]["count"] = 0
			
			
			lot,stop,flag = calculate_lot( last_data,data,flag )
			if lot >= lot_limit_lower:
				out_log_with_line("{0}USDで{1}lotの売りの注文を入れてドテンします\n".format(data["close_price"],lot), flag)
				order_lot, flag = lot_to_amount(data, lot, flag)

				# ここに売り注文のコードを入れる
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Sell',
					amount=order_lot)
				flag["order"]["exist"] = True
				flag["order"]["side"] = "SELL"

				out_log_with_line("{0}USDにストップを入れます\n".format(data["close_price"] + stop), flag)
				flag["position"]["lot"],flag["position"]["stop"] = lot,stop
				flag["position"]["exist"] = True
				flag["position"]["side"] = "SELL"
				flag["position"]["price"] = data["close_price"]
			


	if flag["position"]["side"] == "SELL":
		if signal["side"] == "BUY":
			out_log("過去{0}足の最高値{1}USDを、直近の価格が{2}USDでブレイクしました\n".format(buy_term,signal["price"],data[judge_price["BUY"]]), flag)
			out_log_with_line(str(data["close_price"]) + "USDあたりで成行注文を出してポジションを決済します\n", flag)

			# 決済の成行注文コードを入れる
			if is_back_test is True:
				result = {}
				result["side"] = flag["position"]["side"]
				result["lots"] = flag["position"]["lot"] * data["close_price"]
			else:
				result = get_position()
			
			if (result["side"] == "SELL") and (result["lots"] > 0):
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Buy',
					amount=result["lots"])
				flag["order"]["exist"] = True
				flag["order"]["side"] = "BUY"

			records( flag,data,data["close_price"] )
			flag["position"]["exist"] = False
			flag["position"]["count"] = 0
			flag["position"]["stop-AF"] = stop_AF
			flag["position"]["stop-EP"] = 0
			flag["add-position"]["count"] = 0
			
			
			lot,stop,flag = calculate_lot( last_data,data,flag )
			if lot >= lot_limit_lower:
				out_log_with_line("{0}USDで{1}lotの買いの注文を入れてドテンします\n".format(data["close_price"],lot), flag)
				order_lot, flag = lot_to_amount(data, lot, flag)

				# ここに買い注文のコードを入れる
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Buy',
					amount=order_lot)
				flag["order"]["exist"] = True
				flag["order"]["side"] = "BUY"
				
				out_log_with_line("{0}USDにストップを入れます\n".format(data["close_price"] - stop), flag)
				flag["position"]["lot"],flag["position"]["stop"] = lot,stop
				flag["position"]["exist"] = True
				flag["position"]["side"] = "BUY"
				flag["position"]["price"] = data["close_price"]
	out_log("#-------------close_position end----------------\n", flag)
	return flag



# 損切ラインにかかったら成行注文で決済する関数
def stop_position( data,flag ):
	out_log("#-------------stop_position start----------------\n", flag)
	# トレイリングストップを実行
	flag = trail_stop( data,flag )

	if flag["position"]["side"] == "BUY":
		stop_price = flag["position"]["price"] - flag["position"]["stop"]
		if data["low_price"] < stop_price:
			out_log_with_line("{0}USDの損切ラインに引っかかりました。\n".format( stop_price ), flag)
			stop_price = round( stop_price - 2 * calculate_volatility(last_data) / ( chart_sec / 60))
			out_log_with_line(str(stop_price) + "USDあたりで成行注文を出してポジションを決済します\n", flag)

			# 決済の成行注文コードを入れる

			if is_back_test is True:
				result = {}
				result["side"] = flag["position"]["side"]
				result["lots"] = flag["position"]["lot"] * data["close_price"]
			else:
				result = get_position()				

			if (result["side"] == "BUY") and (result["lots"] > 0):
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Sell',
					amount=result["lots"])
				flag["order"]["exist"] = True
				flag["order"]["side"] = "SELL"

			records( flag,data,stop_price,"STOP" )
			flag["position"]["exist"] = False
			flag["position"]["count"] = 0
			flag["position"]["stop-AF"] = stop_AF
			flag["position"]["stop-EP"] = 0
			flag["add-position"]["count"] = 0
	
	
	if flag["position"]["side"] == "SELL":
		stop_price = flag["position"]["price"] + flag["position"]["stop"]
		if data["high_price"] > stop_price:
			out_log_with_line("{0}USDの損切ラインに引っかかりました。\n".format( stop_price ), flag)
			stop_price = round( stop_price + 2 * calculate_volatility(last_data) / (chart_sec / 60) )
			out_log_with_line(str(stop_price) + "USDあたりで成行注文を出してポジションを決済します\n", flag)

			# 決済の成行注文コードを入れる
			if is_back_test is True:
				result = {}
				result["side"] = flag["position"]["side"]
				result["lots"] = flag["position"]["lot"] * data["close_price"]
			else:
				result = get_position() 

			if (result["side"] == "SELL") and (result["lots"] > 0):
				create_order(
					symbol = symbol_type,
					type='Market',
					side='Buy',
					amount=result["lots"])
				flag["order"]["exist"] = True
				flag["order"]["side"] = "BUY"

			records( flag,data,stop_price,"STOP" )
			flag["position"]["exist"] = False
			flag["position"]["count"] = 0
			flag["position"]["stop-AF"] = stop_AF
			flag["position"]["stop-EP"] = 0
			flag["add-position"]["count"] = 0

	out_log("#-------------stop_position end----------------\n", flag)
	return flag

#------------注文を管理する関数--------------

# 売買注文の約定確認を行う関数
def create_order( symbol, type, side, amount, price=None ):
	out_log("#-------------create_order start----------------\n", flag)
	"""
	引数
	symbol(str) : 'BTC/USD'
	type(str) : 'Limit' -> 指値　/ 'Market' -> 成行
	side(str) : 'Buy' -> 買い / 'Sell' -> 売り
	amount(float/int) -> 注文枚数
	price(float/int) -> 注文価格(成行の場合は省略可)
	"""
	if is_back_test is True:
		out_log("#-------------create_order end----------------\n", flag)
		return 0
	
	while True:
		result = {}
		try:
			# Stop注文の場合はstopPxに指値を入れる（指値を下回ると成り行き決済)
			if type == 'Stop':
				create_order = bitmex.privatePostOrder({
					'symbol' : symbol,
					'type' : type,
					'side' : side,
					'orderQty' : amount,
					'stopPx' : price,
					})
				break
			else:
				create_order = bitmex.privatePostOrder({
					'symbol' : symbol,
					'type' : type,
					'side' : side,
					'orderQty' : amount,
					'price' : price
					})
				break
		except ccxt.BaseError as e:
			out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
			out_log("注文の通信が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
			time.sleep(wait*order_retry_times)

	out_log("#-------------create_order end----------------\n", flag)

	return create_order

# 売買注文の約定確認を行う関数
def check_order():
	"""
	引数 : なし
	戻り値 : 未約定の注文ID
	"""
	if is_back_test is True:
		return 0
	
	while True:
		try:
			out_log("約定を確認します\n", flag)

			orders = []
			order_id = []
			len_orders = 0
			orders = bitmex.fetch_open_orders()

			if len(orders) > 0:
				len_orders = len(orders)
				out_log("ID = {0} が残っています\n".format(len_orders), flag)

				for i in orders:
					order_id.append(i['info']['orderID'])

			elif orders == []:
				out_log("残っている注文はありません\n", flag)
				order_id = 0

			return order_id

		except ccxt.BaseError as e:
			out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
			out_log("売買注文の約定確認が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
			time.sleep(wait*order_retry_times)

# 売買注文のキャンセルを行う関数
def cancel_order(order_id):
	"""
	引数 : なし
	戻り値 : キャンセルの結果（全部成功=1、それ以外=0）
	"""
	while True:
		try:
			out_log("オーダーキャンセル実施\n", flag)

			cancel_order = []

			if order_id != 0:
				for i in order_id:
					cancel_result = bitmex.cancel_order(i)
					cancel_order.append(cancel_result['info']['ordStatus'])


			return cancel_order

		except ccxt.BaseError as e:
			out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
			out_log("売買注文キャンセルが失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
			time.sleep(wait*order_retry_times)

# 口座残高を取得する関数
def get_collateral():
	"""
	引数 : なし
	戻り値 
		result['total'] # 証拠金総額
		result['used'] # 拘束中証拠金
		result['free'] # 使用可能証拠金
	"""
	while True:
		result = {}
		try:
			# 口座残高を取得
			collateral = bitmex.fetch_balance()
			# 総額
			result['total'] = collateral['BTC']['total']
			# 拘束中
			result['used'] = collateral['BTC']['used']
			# 使用可能
			result['free'] = collateral['BTC']['free']

			return result

		except ccxt.BaseError as e:
			out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
			out_log("口座残高取得が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
			time.sleep(wait*order_retry_times)

# ポジション情報を取得する関数
def get_position():
	"""
	引数 : なし
	戻り値 
		result['side'] # None->ノーポジ、BUY->ロング、SELL->ショート
		result['used'] # 拘束中証拠金
		result['free'] # 使用可能証拠金
		result['lots'] # ロットサイズ
		result['averageprice'] # 全ロットの平均価格
	"""
	while True:
		result = {}
		try:

			position = bitmex.private_get_position()
			if position == []:
				result['side'] = 'NONE'
				result['lots'] = 0
			else:
				result['lots'] = abs(float(position[0]['currentQty']))

				if position[0]['currentQty'] < 0:
					result['side'] = 'SELL'
				elif position[0]['currentQty'] > 0:
					result['side'] = 'BUY'
				else:
					result['side'] = 'NONE'

			return result

		except ccxt.BaseError as e:
			out_log("BitmexのAPIでエラー発生 = {0}\n".format(e), flag)
			out_log("ポジション情報取得が失敗しました。{0}秒後に再トライします\n".format(wait*order_retry_times), flag)
			time.sleep(wait*order_retry_times)

			return result

#------------バックテストの部分の関数--------------


# 各トレードのパフォーマンスを記録する関数
def records(flag,data,close_price,close_type=None):
	
	out_log("entry_price = {}\n".format(flag["position"]["price"]), flag)
	out_log("close_price = {}\n".format(close_price), flag)
	out_log("lot = {}\n".format(flag["position"]["lot"]), flag)

	# 取引手数料等の計算
	entry_price = int(round(flag["position"]["price"] * flag["position"]["lot"]))
	exit_price = int(round(close_price * flag["position"]["lot"]))

	if is_back_test is True:
		trade_cost = round( exit_price * slippage )
		log = "スリッページ・手数料として " + str(round( trade_cost/close_price, 4)) + "USDを考慮します\n"
		out_log(log, flag)
	else:
		trade_cost = 0

	flag["records"]["slippage"].append(trade_cost)
	
	# 手仕舞った日時と保有期間を記録
	flag["records"]["date"].append(data["close_time_dt"])
	flag["records"]["holding-periods"].append( flag["position"]["count"] )
	
	# 損切りにかかった回数をカウント
	if close_type == "STOP":
		flag["records"]["stop-count"].append(1)
	else:
		flag["records"]["stop-count"].append(0)
	
	# 値幅の計算
	buy_profit = exit_price - entry_price - trade_cost
	sell_profit = entry_price - exit_price - trade_cost

	# 利益が出てるかの計算
	if flag["position"]["side"] == "BUY":
		flag["records"]["side"].append( "BUY" )
		flag["records"]["profit"].append( buy_profit )
		flag["records"]["return"].append( round( buy_profit / entry_price * 100, 4 ))
		out_log("before_funds = {}\n".format(flag["records"]["funds"]), flag)
		flag["records"]["funds"] = flag["records"]["funds"] + (buy_profit)
		out_log("after_funds = {}\n".format(flag["records"]["funds"]), flag)
		if buy_profit  > 0:
			log = str(buy_profit) + "USDの利益です\n\n"
		else:
			log = str(buy_profit) + "USDの損失です\n\n"
		out_log_with_line(log, flag)
	
	if flag["position"]["side"] == "SELL":
		flag["records"]["side"].append( "SELL" )
		flag["records"]["profit"].append( sell_profit )
		flag["records"]["return"].append( round( sell_profit / entry_price * 100, 4 ))
		out_log("before_funds = {}\n".format(flag["records"]["funds"]), flag)
		flag["records"]["funds"] = flag["records"]["funds"] + (sell_profit)
		out_log("after_funds = {}\n".format(flag["records"]["funds"]), flag)
		if sell_profit > 0:
			log = str(sell_profit) + "USDの利益です\n\n"
		else:
			log = str(sell_profit) + "USDの損失です\n\n"
		out_log_with_line(log, flag)

	return flag

# 設定項目

# バックテストの集計用の関数
def backtest(flag):
	
	# 成績を記録したpandas DataFrameを作成
	records = pd.DataFrame({
		"Date"	   :  pd.to_datetime(flag["records"]["date"]),
		"Profit"   :  flag["records"]["profit"],
		"Side"	   :  flag["records"]["side"],
		"Rate"	   :  flag["records"]["return"],
		"Stop"	   :  flag["records"]["stop-count"],
		"Periods"  :  flag["records"]["holding-periods"],
		"Slippage" :  flag["records"]["slippage"]
	})
	
	# 連敗回数をカウントする
	consecutive_defeats = []
	defeats = 0
	for p in flag["records"]["profit"]:
		if p < 0:
			defeats += 1
		else:
			consecutive_defeats.append( defeats )
			defeats = 0
	
	# 総損益の列を追加する
	records["Gross"] = records.Profit.cumsum()
	
	# 資産推移の列を追加する
	records["Funds"] = records.Gross + start_funds
	
	# 最大ドローダウンの列を追加する
	records["Drawdown"] = records.Funds.cummax().subtract(records.Funds)
	records["DrawdownRate"] = round(records.Drawdown / records.Funds.cummax() * 100,1)
	
	# 買いエントリーと売りエントリーだけをそれぞれ抽出する
	buy_records = records[records.Side.isin(["BUY"])]
	sell_records = records[records.Side.isin(["SELL"])]
	
	# 月別のデータを集計する
	records["月別集計"] = pd.to_datetime( records.Date.apply(lambda x: x.strftime('%Y/%m')))
	grouped = records.groupby("月別集計")
	
	month_records = pd.DataFrame({
		"Number"   :  grouped.Profit.count(),
		"Gross"	   :  grouped.Profit.sum(),
		"Funds"	   :  grouped.Funds.last(),
		"Rate"	   :  round(grouped.Rate.mean(),2),
		"Drawdown" :  grouped.Drawdown.max(),
		"Periods"  :  grouped.Periods.mean()
		})
	
	print("バックテストの結果")
	print("-----------------------------------")
	print("買いエントリの成績")
	print("-----------------------------------")
	print("トレード回数		  :	 {}回".format( len(buy_records) ))
	print("勝率				  :	 {}％".format(round(len(buy_records[buy_records.Profit>0]) / len(buy_records) * 100,1)))
	print("平均リターン		  :	 {}％".format(round(buy_records.Rate.mean(),2)))
	print("総損益			  :	 {}USD".format( buy_records.Profit.sum() ))
	print("平均保有期間		  :	 {}足分".format( round(buy_records.Periods.mean(),1) ))
	print("損切りの回数		  :	 {}回".format( buy_records.Stop.sum() ))
	
	print("-----------------------------------")
	print("売りエントリの成績")
	print("-----------------------------------")
	print("トレード回数		  :	 {}回".format( len(sell_records) ))
	print("勝率				  :	 {}％".format(round(len(sell_records[sell_records.Profit>0]) / len(sell_records) * 100,1)))
	print("平均リターン		  :	 {}％".format(round(sell_records.Rate.mean(),2)))
	print("総損益			  :	 {}USD".format( sell_records.Profit.sum() ))
	print("平均保有期間		  :	 {}足分".format( round(sell_records.Periods.mean(),1) ))
	print("損切りの回数		  :	 {}回".format( sell_records.Stop.sum() ))
	
	print("-----------------------------------")
	print("総合の成績")
	print("-----------------------------------")
	print("全トレード数		  :	 {}回".format(len(records) ))
	print("勝率				  :	 {}％".format(round(len(records[records.Profit>0]) / len(records) * 100,1)))
	print("平均リターン		  :	 {}％".format(round(records.Rate.mean(),2)))
	print("平均保有期間		  :	 {}足分".format( round(records.Periods.mean(),1) ))
	print("損切りの回数		  :	 {}回".format( records.Stop.sum() ))
	print("")
	print("最大の勝ちトレード :	 {}USD".format(records.Profit.max()))
	print("最大の負けトレード :	 {}USD".format(records.Profit.min()))
	print("最大連敗回数		  :	 {}回".format( max(consecutive_defeats) ))
	print("最大ドローダウン	  :	 {0}USD / {1}％".format(-1 * records.Drawdown.max(), -1 * records.DrawdownRate.loc[records.Drawdown.idxmax()]  ))
	print("利益合計			  :	 {}USD".format( records[records.Profit>0].Profit.sum() ))
	print("損失合計			  :	 {}USD".format( records[records.Profit<0].Profit.sum() ))
	print("最終損益			  :	 {}USD".format( records.Profit.sum() ))
	print("")
	print("初期資金			  :	 {}USD".format( start_funds ))
	print("最終資金			  :	 {}USD".format( records.Funds.iloc[-1] )) 
	print("運用成績			  :	 {}％".format( round(records.Funds.iloc[-1] / start_funds * 100,2) )) 
	print("手数料合計		  :	 {}USD".format( -1 * records.Slippage.sum() ))
	
	
	file_name = str(format(datetime.now().strftime("%Y-%m-%d-%H-%M"))) + "-log.png"
	
	# ログファイルの出力
	file =	open("./{0}-log.txt".format(datetime.now().strftime("%Y-%m-%d-%H-%M")),'wt',encoding='utf-8')
	file.writelines(flag["records"]["log"])

	# 損益曲線をプロット
	plt.plot( records.Date, records.Funds )
	plt.xlabel("Date")
	plt.ylabel("Balance")
	plt.xticks(rotation=50) # X軸の目盛りを50度回転
	
	# グラフ描画
	plt.show()
	
	# グラフ画像保存
	plt.savefig(file_name)
	
#------------ここからメイン処理--------------

# チャートを取得
price = get_price(chart_sec,after=1451606400)

flag = {
	"position":{
		"exist" : False,
		"side" : "",
		"price": 0,
		"stop":0,
		"stop-AF": stop_AF,
		"stop-EP":0,
		"ATR":0,
		"lot":0,
		"count":0
	},
	"order":{
		"exist" : False,
		"side" : "",
		"count" : 0
	},
	"add-position":{
		"count":0,
		"first-entry-price":0,
		"last-entry-price":0,
		"unit-range":0,
		"unit-size":0,
		"stop":0
	},
	"records":{
		"date":[],
		"profit":[],
		"return":[],
		"side":[],
		"stop-count":[],
		"funds" : start_funds,
		"holding-periods":[],
		"slippage":[],
		"log":[]
	}
}


last_data = []
need_term = max(buy_term,sell_term,volatility_term)

i = 0
time_cnt = 0 #LINE通知用時間計測

# レバレッジ設定
if is_back_test is False:
	bitmex.private_post_position_leverage(
		{"symbol":symbol_type,
		 "leverage": str(levarage)}
	)

while i < len(price): #バックテスト用
#while True:

	last_data_idx = 0

	if is_back_test is True:
		wait = 0

	# ドンチャンの判定に使う期間分の安値・高値データを準備する
	if len(last_data) < need_term:
		if is_back_test is True:
			last_data.append(price[i])
			flag = log_price(price[i],flag)
			i += 1
			continue
		else:
			last_data_idx = -1 * (need_term - i + 1)
			last_data.append(price[last_data_idx])
			flag = log_price(price[last_data_idx],flag)
			i += 1
			continue

	# 価格を取得
	if is_back_test is True:
		data = price[i]	 # バックテスト用
		new_price = data # バックテスト用
	else:
		data = get_price(chart_sec)
		new_price = data[-2]
		prev_price = last_data[-1]
	
		if new_price["close_time"] == prev_price["close_time"]:
			time.sleep(wait)
			continue
		else:
			time_cnt = time_cnt + 1

	flag = log_price(new_price,flag)
	
	# ポジションがある場合
	if flag["position"]["exist"]:
		flag = stop_position( new_price,flag )
		flag = close_position( new_price,last_data,flag )
		flag = add_position( new_price,flag )
	
	# ポジションがない場合
	else:
		flag = entry_signal( new_price,last_data,flag )
	
	# 稼働状況をLINE通知
	# 6時間に1回通知する
	if time_cnt >= 6:
		# LINE通知メッセージ作成
		result_pos = get_position()
		result_col = get_collateral()
		line_text =  "\n時間： " + str(datetime.fromtimestamp(new_price["close_time"]).strftime('%Y/%m/%d %H:%M')) + "\n高値： " + str(new_price["high_price"]) + "\n安値： " + str(new_price["low_price"]) + "\n終値： " + str(new_price["close_price"]) + "\n"
		line_text = line_text + "\nポジション:{}\nロット:{}\n拘束中証拠金:{}\n使用可能証拠金:{}\n".format(result_pos["side"],result_pos["lots"],round(result_col["used"],4),round(result_col["free"],4))
		"""
		引数 : なし
		戻り値 
			result['side'] # None->ノーポジ、BUY->ロング、SELL->ショート
			result['used'] # 拘束中証拠金
			result['free'] # 使用可能証拠金
			result['lots'] # ロットサイズ
			result['averageprice'] # 全ロットの平均価格
		"""
		# 現在の時間、ポジション数、証拠金
		line_notify(line_text)
		time_cnt = 0
	
	last_data.append( new_price )
	i += 1
	time.sleep(wait)

print("--------------------------")
print("テスト期間：")
print("開始時点 : " + str(price[0]["close_time_dt"]))
print("終了時点 : " + str(price[-1]["close_time_dt"]))
print(str(len(price)) + "件のローソク足データで検証")
print("--------------------------")

backtest(flag)