# APIキー(本番用) 2021/11/22 に失効
apiKey = '5v3pRn2iQwmqa1TT3M' #bybit
# APIシークレットキー(本番用)
secret = 'deZW2HWrNlqSp34ccpj66r4fAQI6SssWlpSM' #bybit
# 通知用LINEトークン
line_token = "hCddmAoaCRUBKG59Yf3BlK1KBHrwkOFelehDxzqraFl"
# ログファイル名
log_file_name = "./satosystem.log"
